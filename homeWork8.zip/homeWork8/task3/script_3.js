jQuery('.head').css('backgroundColor', 'green');
$('h2 .inner').css('fontSize', '35px');