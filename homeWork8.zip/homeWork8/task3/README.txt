you need jQuey to be installed
you can use package-lock.json file and command npm install in your 
project folder